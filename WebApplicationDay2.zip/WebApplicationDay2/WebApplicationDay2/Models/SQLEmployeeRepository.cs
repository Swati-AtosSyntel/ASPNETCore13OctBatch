﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplicationDay2.Models
{
    public class SQLEmployeeRepository : IEmployeeRepository
    {
        public SQLEmployeeRepository(AppDbContext context)
        {
            this.context = context;
        }

        public AppDbContext context { get; }

        public void AddNewEmployee(Employee e)
        {
            context.employees.Add(e);
            context.SaveChanges();
        }

        public void DeleteEmployee(int id)
        {
            Employee e = context.employees.Find(id);
            context.employees.Remove(e);
            context.SaveChanges();
        }

        public Employee GetEmployee(int id)
        {
            return context.employees.Find(id);
        }

        public List<Employee> GetEmployees()
        {
            return context.employees.ToList();
        }

        public void UpdateEmployee(Employee newEmployee)
        {
            var employee = context.employees.Attach(newEmployee);
            employee.State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            context.SaveChanges();

        }
    }
}
