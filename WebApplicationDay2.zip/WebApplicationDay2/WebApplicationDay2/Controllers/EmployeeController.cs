﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace WebApplicationDay2.Controllers
{
    public class EmployeeController : Controller
    {
        public EmployeeController(ILogger<EmployeeController> logger)
        {
            Logger = logger;
        }

        public ILogger<EmployeeController> Logger { get; }

        public IActionResult Index()
        {
            Logger.LogInformation("This message is coming from EmployeeController");
            Logger.LogError("Error Ocurred");

            //return ViewComponent("EmployeeList",new { n = 3 });
            return View();
        }
    }
}