﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplicationDay2.Models;

namespace WebApplicationDay2.Controllers
{
    public class HomeController : Controller
    {
        public HomeController(IEmployeeRepository employeeRepository)
        {
            this.employeeRepository = employeeRepository;
        }

        public IEmployeeRepository employeeRepository { get; }

        public IActionResult Index()
        {
            return View(employeeRepository.GetEmployees());
        }
        public IActionResult Search(int id)
        {

            return View(employeeRepository.GetEmployee(id));
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Employee e)
        {
            if (ModelState.IsValid)
            {
                employeeRepository.AddNewEmployee(e);
                return RedirectToAction("Index");
            }
            return View();
        }
    }
}