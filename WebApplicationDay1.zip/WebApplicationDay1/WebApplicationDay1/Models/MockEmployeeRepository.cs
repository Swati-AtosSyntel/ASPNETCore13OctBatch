﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplicationDay1.Models
{
    public class MockEmployeeRepository : IEmployeeRepository
    {
        List<Employee> employees = new List<Employee>()
        {
            new Employee(){eid=1,ename="Aditi",location="pune"},
            new Employee(){eid=2,ename="Rahul",location="pune"}

        };
        public void AddNewEmployee(Employee e)
        {
            employees.Add(e);

        }

        public Employee GetEmployee(int id)
        {
            return employees.SingleOrDefault(emp => emp.eid == id);
        }

        public List<Employee> GetEmployees()
        {
            return employees;  
        }
    }
}
