﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplicationDay1.Models
{
    public class Employee
    {
        public int eid { get; set; }
        public string ename { get; set; }
        public string location { get; set; }
    }
}
